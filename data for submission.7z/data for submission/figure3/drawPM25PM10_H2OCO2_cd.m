clc;close all;clear

%Beijing:��������,����,��̳,ũչ��,��԰,����������,��������,�ų�,
% %pm25(8); pm10(9);so2(10);no2(11);o3(12);co(13)
obsdir = 'D:\observation\20161216Event\data for submission\data\pm25pm10\'; %change
flist0=ls(obsdir);
sizeflist0=size(flist0);
flist=flist0(3:sizeflist0(1),:);

 for i=1:8
     infile=strcat(obsdir,flist(i,:))
     data=load(infile);
     L=data==-9999.0|data==9999;
     data(L)=nan;
     pm25(:,i)=data(:,8);
     pm10(:,i)=data(:,9);
     co(:,i)=data(:,13);
     o3(:,i)=data(:,12);
     so2(:,i)=data(:,10);
     no2(:,i)=data(:,11);
 end
 
  %% choose co2, unit, mmol/m^3---g/m^3
 co2=load('D:\observation\20161216Event\data for submission\data\hourly mean CO2 from 325 m Tower by LI-7500A.txt');
 co2=co2*44/1000;
%   aa=co2;
% bb=aa(1+24*14:24*21);
% cc=reshape(bb,24,7);
% dd=nanmean(cc);
 
   %% choose h2o, unit, mmol/m^3---g/m^3
 h2o=load('D:\observation\20161216Event\data for submission\data\hourly mean H2O from 325 m Tower by LI-7500A.txt');
 h2o=h2o*18/1000;
 
   aa=h2o;
bb=aa(1+24*14:24*21);
cc=reshape(bb,24,7);
dd=nanmean(cc);


%    aa=nanmean(pm25,2);
% bb=aa(1+24*14:24*21);
% cc=reshape(bb,24,7);
% dd=nanmean(cc);
x=1:1:length(pm25);
figure(1)
h1=subplot('position',[0.15 0.15 0.78 0.35]);
plot(nanmean(pm25,2),'b-','linewidth',2);hold on
plot(nanmean(pm10,2),'k-','linewidth',2)
leg1=legend('PM_{2.5}','PM_{10}','Location','southeast')
set(leg1,'Orientation','horizontal')
set(leg1,'Box','off')
set(gca,'xlim',[1+24*14,1+24*21])
set(gca,'xtick',1+24*14:24:length(data))
set(gca, 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(gca,'ylim',[0,600])
set(gca,'ytick',0:100:600)
set(gca, 'yticklabel', {'0','','200','','400','','600','','800','','1000'})
set(gca,'Fontsize',14);
strlabel=strcat('\fontsize{14}Aerosol (\mug\cdotm^{-3})');
ylabel({strlabel});

figure(2)
h1=subplot('position',[0.1 0.15 0.78 0.35]);
[AX,H1,H2] = plotyy(x,h2o,x,co2,'plot');hold on
set(H1,'LineStyle','-','color','k','linewidth',2);
set(H2,'LineStyle','-','color','b','linewidth',2,'markersize',10);
set(AX(1),'XColor','k','YColor','k','Fontsize',14);
set(get(AX(1),'Ylabel'),'String','\fontsize{14}\rho_{H2O} (g\cdotm^{-3})','color','k');
set(get(AX(1),'xlabel'),'String','\fontsize{14}Date','color','k');
set(AX(1),'xlim',[1+24*14,1+24*21])
set(AX(1),'xtick',1+24*14:24:length(data))
set(AX(1), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(1),'ylim',[2,6])
set(AX(1),'ytick',2:1:6)
set(AX(1), 'yticklabel', {'2','','4','','6','','800','','1000'})

set(AX(2),'XColor','k','YColor','b','Fontsize',14);
set(get(AX(2),'Ylabel'),'String','\fontsize{14}CO_2 (g\cdotm^{-3}) ','color','b');
set(AX(2),'xlim',[1+24*14,1+24*21])
set(AX(2),'xtick',1+24*14:24:length(data))
set(AX(2), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(2),'ylim',[0.7,1.5])
set(AX(2),'ytick',0.7:0.2:1.5)
set(AX(2), 'yticklabel', {'0.7','','1.1','','1.5','','1.9','','2.5'})

