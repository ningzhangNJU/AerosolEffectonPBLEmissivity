clear temp1;clear temp2; close all;clc;clear

infile='D:\observation\20161216Event\data for submission\data\RA47m\TOA5_1606.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR47m=data1(:,2);
UR47m=data1(:,3);
LD47m=data1(:,4);
LU47m=data1(:,5);
RN47m=data1(:,6);

infile='D:\observation\20161216Event\data for submission\data\RA140m\TOA5_1876.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR140m=data1(:,2);
UR140m=data1(:,3);
LD140m=data1(:,4);
LU140m=data1(:,5);
RN140m=data1(:,6);

infile='D:\observation\20161216Event\data for submission\data\RA280m\TOA5_1499.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR280m=data1(:,2);
UR280m=data1(:,3);
LD280m=data1(:,4);
LU280m=data1(:,5);
RN280m=data1(:,6);

figure(1)
h1=subplot('position',[0.15 0.15 0.78 0.35]);
plot(DR280m,'r-','linewidth',2);hold on
plot(DR140m,'r--','linewidth',2);hold on
plot(DR47m,'r-.','linewidth',2);hold on
plot(UR280m,'b-','linewidth',2)
plot(UR140m,'b--','linewidth',2)
plot(UR47m,'b-.','linewidth',2)
leg1=legend('DSR_{280}','DSR_{140}','DSR_{47}','USR_{280}','USR_{140}','USR_{47}','Location','northeast','NumColumns',3);hold on
set(leg1,'Orientation','horizontal')
set(leg1,'Box','off')
strlabel=strcat('\fontsize{13} SR (W\cdotm^{-2})');
ylabel({strlabel});
set(gca,'xlim',[1+48*14,1+48*21])
set(gca,'xtick',1+48*14:48:length(DR47m))
set(gca, 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(gca,'Fontsize',14);
strg1=['print -dpng SR.tif'];eval(strg1)



aa=LD47m(1+48*14:48*21);
bb=LU47m(1+48*14:48*21);
cc=reshape(bb,48,7);
dd=mean(cc);

figure(2)
h1=subplot('position',[0.15 0.15 0.78 0.35]);
plot(LD280m,'r-','linewidth',2);hold on
plot(LD140m,'r--','linewidth',2);hold on
plot(LD47m,'r-.','linewidth',2);hold on
plot(LU280m,'b-','linewidth',2)
plot(LU140m,'b--','linewidth',2)
plot(LU47m,'b-.','linewidth',2)
leg2=legend('DLR_{280}','DLR_{140}','DLR_{47}','ULR_{280}','ULR_{140}','ULR_{47}','Location','southeast','NumColumns',3)
set(leg2,'Orientation','horizontal')
set(leg2,'Box','off')
strlabel=strcat('\fontsize{13} LR (W\cdotm^{-2})');
ylabel({strlabel});
set(gca,'ylim',[150,360])
set(gca,'xlim',[1+48*14,1+48*21])
set(gca,'xtick',1+48*14:48:length(DR47m))
set(gca, 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(gca,'Fontsize',14);
strg1=['print -dpng LR.tif'];eval(strg1)


