clc;close all;clear
data0=load('D:\observation\20161216Event\data for submission\data\Beijing_54511.txt');

L=data0==-9999.0|data0==9999;
data0(L)=nan;

data(1:72,:)=data0(1:72,:)*nan;
data(73:24*31,:)=data0;

x=1:1:length(data);

figure(1)
h1=subplot('position',[0.1 0.15 0.78 0.35]);
[AX,H1,H2] = plotyy(x,data(:,8),x,data(:,7),'plot');hold on
set(H1,'LineStyle','-','color','k','linewidth',2);
set(H2,'LineStyle','none','Marker','.','color','b','linewidth',2,'markersize',10);
set(AX(1),'XColor','k','YColor','k','Fontsize',14);
set(get(AX(1),'Ylabel'),'String','\fontsize{14}U (m\cdots^{-1})','color','k');
set(get(AX(1),'xlabel'),'String','\fontsize{14}Date','color','k');
set(AX(1),'xlim',[1+24*14,1+24*21])
set(AX(1),'xtick',1+24*14:24:length(data))
set(AX(1), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(1),'ylim',[0,8])
set(AX(1),'ytick',0:1:8)
set(AX(1), 'yticklabel', {'0','','2','','4','','6','','8'})

set(AX(2),'XColor','k','YColor','b','Fontsize',14);
% set(get(AX(2),'Ylabel'),'String','\fontsize{14}WD (^o)','color','b');
set(get(AX(2),'Ylabel'),'String','\fontsize{14}WD ','color','b');
set(AX(2),'xlim',[1+24*14,1+24*21])
set(AX(2),'xtick',1+24*14:24:length(data))
set(AX(2), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(2),'ylim',[0,360])
set(AX(2),'ytick',0:45:360)
% set(AX(2), 'yticklabel', {'0','','90','','180','','270','','360'})
set(AX(2), 'yticklabel', {'N','','E','','S','','W','','N'})

set(gcf,'CurrentAxes', AX(1));hold on;

% legend('\lambda^a','\lambda^f')

set(gca,'Fontsize',14);
% strg1=['print -dpng wind_speed_dir.tif'];eval(strg1)


td=data(:,17);
E0=6.11;
e=E0*10.^((7.5*td)./(237.3+td));
t=data(:,20);
E=E0*10.^((7.5*t)./(237.3+t));
RH=e./E*100;
figure(2)
h1=subplot('position',[0.1 0.15 0.78 0.35]);
[AX,H1,H2] = plotyy(x,data(:,20),x,RH,'plot');hold on
set(H1,'LineStyle','-','color','k','linewidth',2);
set(H2,'LineStyle','-','color','b','linewidth',2,'markersize',6);
set(AX(1),'XColor','k','YColor','k','Fontsize',14);
set(get(AX(1),'Ylabel'),'String','\fontsize{14}Temp (^oC)','color','k');
set(get(AX(1),'xlabel'),'String','\fontsize{14}Date','color','k');
set(AX(1),'xlim',[1+24*14,1+24*21])
set(AX(1),'xtick',1+24*14:24:length(data))
set(AX(1), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(1),'ylim',[-6,10])
set(AX(1),'ytick',-6:2:10)
 set(AX(1), 'yticklabel', {'-6','','-2','','2','','6','','10'})

set(AX(2),'XColor','k','YColor','b','Fontsize',14);
set(get(AX(2),'Ylabel'),'String','\fontsize{14}RH (%)','color','b');
set(AX(2),'xlim',[1+24*14,1+24*21])
set(AX(2),'xtick',1+24*14:24:length(data))
set(AX(2), 'xticklabel', {'Dec-14','15','16','17','18','19','20','21','22','23','24','','28','','Jan-1'})
set(AX(2),'ylim',[0,100])
set(AX(2),'ytick',0:12.5:100)
set(AX(2), 'yticklabel', {'0','','25','','50','','75','','100'})
set(gcf,'CurrentAxes', AX(1));hold on;
set(gca,'Fontsize',14);
% grid on
strg1=['print -dpng t_RH.tif'];eval(strg1)
