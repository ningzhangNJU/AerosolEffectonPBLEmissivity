clc;clear all;close all;fclose all;

input_dir = 'D:\observation\20161216Event\data for submission\data\325 m tower_mean\'; %change
files = dir(input_dir);
nfiles = length(files);


for ff = 3:nfiles
    infile=[input_dir,files(ff).name]
data0=importdata(infile);
fid=fopen(infile,'r');
str2=textread(infile,'%s','headerlines',7,'delimiter',' ');
    for hh=1:20
    for i=1:90
    temp(i)=str2num(str2{i+(hh-1)*103});
    end
    temp2=reshape(temp,6,15);
    temp3=temp2';
    T320(hh+(ff-3)*48)=temp3(1,6);
    T280(hh+(ff-3)*48)=temp3(2,6);
    T140(hh+(ff-3)*48)=temp3(7,6);  
    T47(hh+(ff-3)*48)=temp3(12,6);
    T8(hh+(ff-3)*48)=temp3(15,6);
    RH320(hh+(ff-3)*48)=temp3(1,5);
    RH140(hh+(ff-3)*48)=temp3(7,5);
             RH47(hh+(ff-3)*48)=temp3(12,5);
    end
      
hh=21;
    for i=1:90
    temp(i)=str2num(str2{i+19*103+102});
    end
    temp2=reshape(temp,6,15);
    temp3=temp2';
    T320(hh+(ff-3)*48)=temp3(1,6);
    T280(hh+(ff-3)*48)=temp3(2,6);
    T140(hh+(ff-3)*48)=temp3(7,6); 
    T47(hh+(ff-3)*48)=temp3(12,6);
    T8(hh+(ff-3)*48)=temp3(15,6);
    RH320(hh+(ff-3)*48)=temp3(1,5);
    RH140(hh+(ff-3)*48)=temp3(7,5);
             RH47(hh+(ff-3)*48)=temp3(12,5);

    for hh=22:48
        for i=1:90
            temp(i)=str2num(str2{i+19*103+102+(hh-21)*101});
        end
        temp2=reshape(temp,6,15);
        temp3=temp2';

        T320(hh+(ff-3)*48)=temp3(1,6);
        T280(hh+(ff-3)*48)=temp3(2,6);
        T140(hh+(ff-3)*48)=temp3(7,6);
        T47(hh+(ff-3)*48)=temp3(12,6);
        T8(hh+(ff-3)*48)=temp3(15,6);
        RH320(hh+(ff-3)*48)=temp3(1,5);
        RH140(hh+(ff-3)*48)=temp3(7,5);
                 RH47(hh+(ff-3)*48)=temp3(12,5);
    end
    
end

L=T320>100;T320(L)=nan;
L=T140>100;T140(L)=nan;
TK8=T8+273.15;TK47=T47+273.15;TK140=T140+273.15;TK280=T280+273.15;TK320=T320+273.15;

clear temp1;clear temp2;
infile='D:\observation\20161216Event\data for submission\data\RA47m\TOA5_1606.RMET_30m.dat';
data0=importdata(infile);data1=data0.data;
LD47m=data1(:,4);
LU47m=data1(:,5);
% L=LD47m>1000; LD47m(L)=nan;

infile='D:\observation\20161216Event\data for submission\data\RA140m\TOA5_1876.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;
LD140m=data1(:,4);
LU140m=data1(:,5);
infile='D:\observation\20161216Event\data for submission\data\RA280m\TOA5_1499.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;
LD280m=data1(:,4);
LU280m=data1(:,5);


sigma=5.67*10^(-8);
FE=sigma.*(((TK280+TK47)/2).^4);
eps47m=(LD47m-LD280m-LU47m+LU280m)./(2*FE'-LD280m-LU47m);

FE_Tmax=sigma.*(((TK140+TK47)/2).^4);
eps47m_Tmax=(LD47m-LD140m-LU47m+LU140m)./(2*FE_Tmax'-LD140m-LU47m);
FE_Tmin=sigma.*(((TK140+TK280)/2).^4);
eps47m_Tmin=(LD140m-LD280m-LU140m+LU280m)./(2*FE_Tmin'-LD280m-LU140m);

obsdir = 'D:\observation\20161216Event\data for submission\data\pm25pm10\'; %change
flist0=ls(obsdir);
sizeflist0=size(flist0);
flist=flist0(3:sizeflist0(1),:);
 for i=1:8
     infile=strcat(obsdir,flist(i,:))
     data=load(infile);
     L=data==-9999.0|data==9999;
     data(L)=nan;
     pm25_all(:,i)=data(:,8);
 end
 
 pm25=nanmean(pm25_all,2);
 pm25(1:24*14)=nan;
 pm25(1+24*19:length(pm25))=nan;
 
  ccc=pm25;
 ddd=reshape(ccc,24,31);
%  ddd(1:8,:)=nan;
%  ddd(20:24,:)=nan;
ddd(8:19,:)=nan;
 eee=reshape(ddd,744,1);
 pm25=eee;


 LRH=RH47>90;
eps47m(LRH)=nan;


tempEPS=reshape(eps47m,2,744);
tempEPS2=tempEPS(1,:);


L=isnan(pm25)|isnan(tempEPS2');
aa=pm25(~L);
bb=tempEPS2(~L)';
P=polyfit(aa,bb,1);

x1=0:1:400;
y= polyval(P,x1);
figure(2)
h1=subplot('position',[0.2 0.2 0.6 0.75]);
plot(aa,bb,'b.','markersize',15);hold on
plot(x1,y,'b-','linewidth',2)
strtext=strcat('y=',num2str(roundn(P(1),-6)),'x+',num2str(roundn(P(2),-2)));

ylabel('\epsilon','FontSize',22);
xlabel('PM_{2.5}(\mug\cdotm^-^3)','FontSize',14);
set(gca,'Fontsize',14);
% xlim([0,6])
ylim([0,0.15])
gtext(strtext,'FontSize',14,'color','b')


L=isnan(pm25);
tempTK=reshape((TK280+TK47)/2,2,744);
temp_TK=tempTK(1,:);
cc=tempTK(~L);
meanTK=mean(cc);
delta_epsilon=P(1)*100;
delta_FE=delta_epsilon*sigma.*(meanTK^4);