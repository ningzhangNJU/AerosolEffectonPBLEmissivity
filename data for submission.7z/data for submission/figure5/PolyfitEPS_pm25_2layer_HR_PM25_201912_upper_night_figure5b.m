clc;clear all;close all;fclose all;

input_dir = 'D:\observation\20161216Event\data for submission\data\325 m tower_mean\'; %change
files = dir(input_dir);
nfiles = length(files);


for ff = 3:nfiles
    infile=[input_dir,files(ff).name]
data0=importdata(infile);

fid=fopen(infile,'r');
str2=textread(infile,'%s','headerlines',7,'delimiter',' ');
    for hh=1:20
    for i=1:90
    temp(i)=str2num(str2{i+(hh-1)*103});
    end
    temp2=reshape(temp,6,15);
    temp3=temp2';
    T320(hh+(ff-3)*48)=temp3(1,6);
    T280(hh+(ff-3)*48)=temp3(2,6);
    T140(hh+(ff-3)*48)=temp3(7,6);  
    T47(hh+(ff-3)*48)=temp3(12,6);
    T8(hh+(ff-3)*48)=temp3(15,6);
    RH320(hh+(ff-3)*48)=temp3(1,5);
    RH140(hh+(ff-3)*48)=temp3(7,5);
             RH47(hh+(ff-3)*48)=temp3(12,5);
             RH8(hh+(ff-3)*48)=temp3(15,5);
    end
      
hh=21;
    for i=1:90
    temp(i)=str2num(str2{i+19*103+102});
    end
    temp2=reshape(temp,6,15);
    temp3=temp2';
    T320(hh+(ff-3)*48)=temp3(1,6);
    T280(hh+(ff-3)*48)=temp3(2,6);
    T140(hh+(ff-3)*48)=temp3(7,6); 
    T47(hh+(ff-3)*48)=temp3(12,6);
    T8(hh+(ff-3)*48)=temp3(15,6);
    RH320(hh+(ff-3)*48)=temp3(1,5);
    RH140(hh+(ff-3)*48)=temp3(7,5);
             RH47(hh+(ff-3)*48)=temp3(12,5);
             RH8(hh+(ff-3)*48)=temp3(15,5);

    for hh=22:48
        for i=1:90
            temp(i)=str2num(str2{i+19*103+102+(hh-21)*101});
        end
        temp2=reshape(temp,6,15);
        temp3=temp2';

        T320(hh+(ff-3)*48)=temp3(1,6);
        T280(hh+(ff-3)*48)=temp3(2,6);
        T140(hh+(ff-3)*48)=temp3(7,6);
        T47(hh+(ff-3)*48)=temp3(12,6);
        T8(hh+(ff-3)*48)=temp3(15,6);
        RH320(hh+(ff-3)*48)=temp3(1,5);
        RH140(hh+(ff-3)*48)=temp3(7,5);
                 RH47(hh+(ff-3)*48)=temp3(12,5);
                 RH8(hh+(ff-3)*48)=temp3(15,5);
    end
    
end

L=T320>100;T320(L)=nan;
L=T140>100;T140(L)=nan;
TK8=T8+273.15;TK47=T47+273.15;TK140=T140+273.15;TK280=T280+273.15;TK320=T320+273.15;





lwdown=[161.6300 176.2900 188.8100 188.7900 176.9000 180.3000 183.3000 187.6700 184.3600 186.9400 198.5400 205.1600 207.2400 208.4400 207.1400 210.7900 209.7800 211.8600 210.7900 210.4900];
lwup  =[281.5700 308.6800 293.5700 297.4700 291.1800 319.7400 293.2200 296.9400 302.1600 336.0500 311.4700 313.5700 310.1700 336.6300 306.4500 310.7100 306.6100 340.5300 309.5800 304.3600];

infile='D:\observation\20161216Event\data for submission\data\RA47m\TOA5_1606.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR47m=data1(:,2);
UR47m=data1(:,3);
LD47m=data1(:,4);
LU47m=data1(:,5);
RN47m=data1(:,6);

infile='D:\observation\20161216Event\data for submission\data\RA140m\TOA5_1876.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR140m=data1(:,2);
UR140m=data1(:,3);
LD140m=data1(:,4);
LU140m=data1(:,5);
RN140m=data1(:,6);

infile='D:\observation\20161216Event\data for submission\data\RA280m\TOA5_1499.RMET_30m.dat';
data0=importdata(infile);
data1=data0.data;

DR280m=data1(:,2);
UR280m=data1(:,3);
LD280m=data1(:,4);
LU280m=data1(:,5);
RN280m=data1(:,6);


%unit, 
%longwave radiative flux: W/m^2,=J/s*m^2=3600*J/h*m^2
%cp          KJ/kg*K=1000J/kg*K
%rou:       kg/m^(3)
%deltaHR: 3.6*K/h

cp=1.005;
rou=1.293;
DeltaHR=3.6/rou/cp*((LD280m-LD140m+LU140m-LU280m)/140);

eps47m=DeltaHR;

obsdir = 'D:\observation\20161216Event\data for submission\data\pm25pm10\'; %change
flist0=ls(obsdir);
sizeflist0=size(flist0);
flist=flist0(3:sizeflist0(1),:);
 for i=1:8
     infile=strcat(obsdir,flist(i,:))
     data=load(infile);
     L=data==-9999.0|data==9999;
     data(L)=nan;
     pm25_all(:,i)=data(:,8);
 end
 
 pm25=nanmean(pm25_all,2);
 pm25(1:24*14)=nan;
 pm25(1+24*19:length(pm25))=nan;
 
  ccc=pm25;
 ddd=reshape(ccc,24,31);
%  ddd(1:8,:)=nan;
%  ddd(20:24,:)=nan;
 ddd(8:19,:)=nan;
 eee=reshape(ddd,744,1);
 pm25=eee;

 
% LRH=RH47>90|eps47m'<=0;
 LRH=RH47>90;
eps47m(LRH)=nan;
% LRH=RH47>90|eps47m_Tmax'<=0;
eps47m_Tmax(LRH)=nan;
% LRH=RH47>90|eps47m_Tmin'<=0;
eps47m_Tmin(LRH)=nan;

tempEPS=reshape(eps47m,2,744);
tempEPS2=tempEPS(1,:);



L=isnan(pm25)|isnan(tempEPS2');
aa=pm25(~L);
bb=tempEPS2(~L)';
P=polyfit(aa,bb,1);
x1=0:1:400;
y= polyval(P,x1);


figure(2)
h1=subplot('position',[0.2 0.2 0.6 0.75]);
plot(aa,bb,'b.','markersize',15);hold on
plot(x1,y,'b-','linewidth',2)
%   strtext=strcat('y=',num2str(roundn(P(1),-6)),'x',num2str(roundn(P(2),-2)));
  strtext=strcat('y=-0.000029x',num2str(roundn(P(2),-2)));

ylabel('HR (K\cdoth^{-1}) ','FontSize',22);
xlabel('PM_{2.5}(\mug\cdotm^{-3})','FontSize',14);
set(gca,'Fontsize',14);
% xlim([0,6])
ylim([-0.3,0.3])
gtext(strtext,'FontSize',14,'color','b')

strg=strcat('print -dpng deltaHR','.png');
strg1=[strg];
eval(strg1)

cc=bb(aa<400&aa>=300);
meanCC=mean(cc);